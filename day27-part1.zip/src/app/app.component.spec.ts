import { AppComponent } from "./app.component";

describe("Testing AppComponent",()=>{
  let app:AppComponent;
 describe("testting for title only",()=>{
  beforeAll(()=>{
    app = new AppComponent();
   console.log("before all is called")
  });
  beforeEach(()=>{
    console.log("before each is called")
  });
  afterEach(()=>{
    console.log("after each is called")
  });
  afterAll(()=>{
    console.log("after all is called")
  });
  it("should check for app to be defined",()=>{
    expect(app.title).toBe('steps');

  });
  it("should check for app to be defined",()=>{
    expect(app).toBeDefined();

  });
  it("should check for app to be defined",()=>{
    expect(app.title.length).toBe(5);

  });
  it("should check for app to be defined",()=>{
    expect(app.userage).toBeDefined();

  });
 })
 describe("testing for age",()=>{
  beforeAll(()=>{
    app = new AppComponent();
   console.log("before all is called")
  });
  it("testin for userage",()=>{
    expect(app.userage).toBe(18);
  });
  it("testing for userage to be 19",()=>{
    app.increaseAge();
    expect(app.userage).toBe(19);
  })
  afterEach(()=>{
    app.userage = 18;
  })

 })
})