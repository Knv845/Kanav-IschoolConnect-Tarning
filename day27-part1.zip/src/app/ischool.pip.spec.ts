import { IschoolPipe } from "./school.pipe";

describe("testing for pipe",()=>{
    let ischoolpipe:IschoolPipe;
    beforeEach(()=>{
        console.log("beforcheach is called");
        ischoolpipe =  new IschoolPipe;
    });
    it("should be a good pipe",()=>{
        expect(ischoolpipe.transform('kanav','hi')).toBe('hi kanav');
    })
})