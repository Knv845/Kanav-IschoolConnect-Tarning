import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template:`
  <ul>
    <li>Title is : {{title | ischool:'h1'}}</li>
    <li>Useename is : {{username}}</li>
    <li>User age is {{userage}}</li>
  </ul>
`
})

export class AppComponent {
  title = 'steps';
  username="Batman";
  userage=18

  increaseAge(){
    this.userage = this.userage + 1;
  }
}
