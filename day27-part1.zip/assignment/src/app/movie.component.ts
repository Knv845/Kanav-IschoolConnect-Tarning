import { Component, OnInit } from '@angular/core';
import { MovieService } from './movies.services';

@Component({
  selector: 'app-movie',
  template: `
    <div class="container"> 
      <h1>Welcome To Movies</h1>
    <br>
  <table class="table">
  <thead>
    <tr>
      <th scope="col">S no</th>
      <th scope="col">Movie Name</th>
      <th scope="col">Ratings</th>
      <th scope="col">Edit</th>
    </tr>
  </thead>
  <tbody>
    <tr *ngFor="let movie of movielist">
         <td>{{movie.id}}</td>
         <td>{{movie.name}}</td>
         <td>{{movie.rating}}</td>
         <td>
           <button class="btn btn-warning" [routerLink]="['/movieedit',movie.id]">Click To Edit</button>
         </td>
    </tr>
  </tbody>
</table>
    </div>
    <router-outlet></router-outlet>
  `,
  styles: [
  ]
})
export class MovieComponent implements OnInit {
  movielist:any;
  constructor(private ms:MovieService) { }

  ngOnInit(): void {
    this.movielist = this.ms.getmovies()
  }

}
