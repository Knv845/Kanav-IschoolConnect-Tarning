
import { AppComponent } from './app.component';
import { Hero1Component } from './hero.component';
import { HeroesService } from './heroes.service';

describe('AppComponent', () => {
  let app:AppComponent;
  beforeEach( () => {
    console.log('before each componenet is called')
    app = new AppComponent;
  });

  it('app is running', () => {
     expect(app).toBeDefined();
  });
  it('router link is workin', () => {
    expect(app.title).toBe('featured-routes');
 });
 it('router link is workin', () => {
  expect(app.title.length).toBe(15);
});
});

describe('hero service testing', () => {
  let hero:HeroesService;
  beforeEach( () => {
    hero = new HeroesService();
    console.log('before each componenet is called')
  });
  it('get user id function is working', () => {
    expect(hero.getSelectedHeroes).toBeDefined();
  });
  it('get user function is working', () => {
    expect(hero.getHeroes).withContext('batman');
  });
})