"use strict";
alert("we havve started");
