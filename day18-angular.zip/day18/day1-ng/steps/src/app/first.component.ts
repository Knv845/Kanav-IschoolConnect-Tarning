import { Component } from "@angular/core";

@Component({
    selector : 'app-first',
    template : '<h1>first</h1>'

})

export class FirstComp{

}