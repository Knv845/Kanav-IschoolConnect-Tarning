import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, Input, OnChanges, OnDestroy, OnInit } from '@angular/core';
 
@Component({
  selector: 'app-child',
  template : `
      <h1>Children Component</h1>
  `
})
export class ChildComponent implements OnInit, OnChanges, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy{
  title = 'steps';
   
  constructor(){
    console.log("ChildComponent's constructor was called");
  }
  ngOnInit(): void {
    console.log("ChildComponent's ngOnInit was called");
  }
  ngOnChanges(pow:any): void {
    console.log("ChildComponent's ngOnChanges was called");
  }
  ngDoCheck(){
      console.log("ChildComponent's DoCheck was called");
  }
  ngAfterContentInit(){
      console.log("ChildComponent's AfterContentInit was called");
  }
  ngAfterContentChecked(){
      console.log("ChildComponent's AfterContentChecked was called");
  }
  ngAfterViewInit(){
      console.log("ChildComponent's AfterViewInit was called");
  }
  ngAfterViewChecked(){
      console.log("ChildComponent's AfterViewChecked was called");
  }
  ngOnDestroy(){
      console.log("ChildComponent's OnDestroy was called");
  }
}