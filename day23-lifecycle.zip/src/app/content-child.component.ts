import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-child',
  template:`
      <h1>welcome to content child</h1>
      <hr>
      <p> Header is {{header}}</p>
  `
})
export class ContentChildComponent implements OnInit {
 header:any = "This is chnaged header"
  constructor() { }

  ngOnInit(): void {
  }
}
