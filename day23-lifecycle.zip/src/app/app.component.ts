import { Component, OnInit, ViewChild } from '@angular/core';
 
@Component({
  selector: 'app-root',
  template : `
    <h1>Main Component : Power {{ apppower }}</h1>
    <button (click)="increasechildPower()">Increase Power</button>
    <button (click)="decreasechildPower()">Decrease Power</button>
    <button (click)="showHide()">Remove Child Component</button>
    <app-child #powercomp *ngIf="show"></app-child>
    <div>
      <input type="text" #applicationInfo />
      <input type="text" #applicationInfo />
      <input type="text" #applicationInfo />
    </div>
  `
})
export class AppComponent implements OnInit {
  title = 'steps';
  apppower = 0;
  show = true;
  @ViewChild('powercomp') cc:any;
  constructor(){
    console.log("AppComponent's constructor was called");
  }
  ngOnInit(): void {
    this.apppower = 5;
    console.log("AppComponent's ngOnInit was called");
  }
  increasechildPower(){
   this.cc.increasepower()
  }
  decreasechildPower(){
    this.cc.decreasepower()
  }
  showHide(){

    this.show = !this.show;
  }
}
 