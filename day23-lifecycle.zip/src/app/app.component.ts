import { Component, OnInit, ViewChild,ContentChild,ViewChildren,QueryList } from '@angular/core';
 
@Component({
  selector: 'app-root',
  template : `
    <h1>Main Component : Power {{ apppower }}</h1>
    <button (click)="increasechildPower()">Increase Power</button>
    <button (click)="decreasechildPower()">Decrease Power</button>
    <button (click)="showHide()">Remove Child Component</button>
    <app-child #powercomp *ngIf="show"></app-child>
    <app-child1></app-child1>
    <div>
      <input type="text" #applicationInfo />
      <input type="text" #applicationInfo />
      <input type="text" #applicationInfo />
    <app-content-child></app-content-child>
    </div>
  `
})
export class AppComponent implements OnInit {
  title = 'steps';
  apppower = 0;
  //show = true;
  @ViewChild('powercomp') cc:any;
  @ContentChild('header') header: any;
  @ViewChildren('NgModel') list: QueryList<'NgModel'>;
  
    show() {
 
    this.list.forEach((element:any) => {
      console.log(element)
      //console.log(element.value)
    });
  }
  constructor(){
    console.log("AppComponent's constructor was called");
  }
  ngOnInit(): void {
    this.apppower = 5;
    console.log("AppComponent's ngOnInit was called");
  }
  increasechildPower(){
   this.cc.increasepower()
  }
  decreasechildPower(){
    this.cc.decreasepower()
  }
  showHide(){

    this.show = !this.show;
  }
  ngAfterContentInit() {
   
    this.header.header
 
}
}
 