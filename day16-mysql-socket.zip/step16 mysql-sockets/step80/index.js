const express = require("express");
const app = express();
const server = require("http").createServer(app);
const io = require("socket.io")(server);

io.on("connection", function(socket){
    console.log("a client socket is connected");
    socket.emit("message","Hello from Socket.io");
})
app.use(express.static(__dirname))

app.listen(8000,"localhost",function(error){
    if(error){
        console.log(error)
    }else{
        console.log("running")
    }
})