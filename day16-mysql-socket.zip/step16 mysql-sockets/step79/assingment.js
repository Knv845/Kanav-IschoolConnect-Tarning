const res = require("express/lib/response");
let mysql = require("mysql");

let connection = mysql.createConnection({
    host : "localhost",
    user : "root",
    password : "",
   // port : "3308",
    database : "ischooldb"
})

connection.connect(function(error){
    if(error){
        console.log("error",error)
    }else{

//let sql = "SELECT * FROM participants WHERE id < 5";
    //  let sql = "SELECT * FROM participants WHERE id > 5";
     let sql = "SELECT * FROM participants GROUP BY id having mod(id,2)=1;";

         connection.query(sql,function(error,result){
                 if(error){
                     console.log(error)
                 }else{
                     console.log(result)
                     result.forEach(element => {
                         console.log(element.name)
                     });
                 }
             })
            }
})




//joins query
// let sql = `SELECT participants.name, powers.power FROM participants INNER JOIN powers ON participants.id = powers.id`;
// // let sql = `SELECT participants.name, powers.power FROM participants LEFT JOIN powers ON participants.id = powers.id` 
// //let sql = `SELECT participants.name, powers.power FROM participants RIGHT JOIN powers ON participants.id = powers.id`
//   connection.query(sql,function(error,result){