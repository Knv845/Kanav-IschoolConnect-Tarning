let mysql = require("mysql");

let connection = mysql.createConnection({
    host : "localhost",
    user : "root",
    password : "",
  //  port : "3308"
})

connection.connect(function(error){
    if(error){
        console.log("error",error)
    }else{
        console.log("Mysql connected")
    }
})