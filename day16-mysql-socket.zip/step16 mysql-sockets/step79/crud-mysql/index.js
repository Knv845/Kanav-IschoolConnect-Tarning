const config = require("./public/config.json")
const express = require('express')
const app =  express();
const mysql = require('mysql')
// midle ware
app.use(express.static(__dirname+"/public"))
app.use(express.json());
//application configrations

//db configrations
let connection = mysql.createConnection({
    host: 'localhost',
    user : "root",
    password : '',
    port : "3308",
    database : "crudb"
});

//crud routes


    let sql = 'SELECT * FROM users'
    connection.query(sql, function (err, result){
        if (err) {
           console.log(err);
        } else {
            console.log("mysql connected")
            // result.json({result})
            console.log(result)
        }
    })


   // console.log('GET Request for Data Recieved');
    

// //     })
// })

// app.post("/add",function(req,res){
//     //console.log('data recieved',req.body);
//     let users = new Users(req.body);
//     users.save()
//     .then(function(dbres){
//         console.log("data is save dto db")
//     })
//     .catch(function(error){
//         console.log("error occured in send to db")
//     })
// })

// app.delete("/delete/:id",(req,res)=>{
//         console.log("delete request recieved")
//         Users.findByIdAndDelete({_id : req.params.id},function(error, deleteduser){
//             if(error){
//                 console.log("error from delte")
//             }else
//                 res.json({"messags": "user deteled"})
//         })
// })

// app.get("/edit/:id",function(req, res){
//     Users.findById(req.params.id,function(error, userupdate){
//         if(error){
//             console.log("error from edit")
//         }else{
//              res.json(userupdate)
//         }
           
//     })

// })
// app.post("/edit/:id",function(req, res){
//     Users.findById(req.params.id,function(error, updateUser){
//         if(error){
//             console.log("error from edit")
//         }else{
//             updateUser.username = req.body.username;
//             updateUser.usermail = req.body.usermail;
//             updateUser.usercity = req.body.usercity;
//             updateUser.save().
//             then((res)=>{
                
//             }).catch((error)=>{
//                 console.log(error)
//             })
//         }
           
//     })

// })



// app.listen(config.port, function(error){
//     if(error){
//         console.log('error');
        
//     }else
//     console.log(`server is running on ${config.port}`)
// })
// connection.connect(function (error) {
//     if(error){
//         console.log(error);
//     }else{
//         console.log("my sql connected")
//         //let sql =  "CREATE TABLE users (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(225), email VARCHAR(225), city VARCHAR(225))" 
//         // let data = [
//         //         ["Superman","clarkent@gmail.com","new york"],
//         //         ["Batman","brucewyane@gmail.com","gotham"],
    
//         //     ];
//         //      let sql = "INSERT INTO users (name,email,city) VALUES ?";
//         // connection.query(sql,[data],function(error,result){
//         //     if(error){
//         //         console.log(error)
//         //     }else{
//         //         console.log(result)
//         //     }
//         // })
    
//     }
//   })
