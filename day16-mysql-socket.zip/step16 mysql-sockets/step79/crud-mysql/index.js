const config = require("./public/config.json")
const express = require('express')
const app =  express();
const mysql = require('mysql')
const bodyparser = require('body-parser')

// midle ware
app.use(express.static(__dirname+"/public"))
app.use(express.json());
app.use(bodyparser.json())
//application configrations

//db configrations
let connection = mysql.createConnection({
    host: 'localhost',
    user : "root",
    password : '',
    port : "3308",
    database : "crudb"
});

//crud routes

connection.connect(function (error) {
        if(error){
            console.log(error);
        }else{
           //result.json({result})
           console.log("db connected")
            
        }
    })

// revieving in a data base 
app.get("/data",(req,res)=>{
    let sql = "SELECT * FROM users";
    connection.query(sql,function (error, result) {
        if(error){
            console.log(error);
        }else{
            res.json(result)
        }
      })
})
app.post("/add",(req,res)=>{
    let sql = "INSERT INTO users (name,email,city) VALUES (?,?,?)";
    connection.query(sql,[req.body.name,req.body.email,req.body.city],function(error, result) {
        if(error){
            console.log(error);
        }else{
            console.log("record  has been inserted")
        }
      })
})
app.post("/delete/:id",(req,res)=>{
    let sql = "DELETE FROM users WHERE id = ?";
    connection.query(sql,[req.body.id],function(error, result) {
        if(error){
            console.log(error);
        }else{
            console.log("record  has been inserted")
        }
      })
})
app.post("/edit/:id",(req,res)=>{
    let sql = "UPDATE FROM users WHERE id = ?";
    connection.query(sql,[req.body.id],function(error, result) {
        if(error){
            console.log(error);
        }else{
            console.log("record  has been inserted")
        }
      })
})


app.listen(3010,function(error){
    if(error){
        console.log(error)
    }else{
        console.log("server is running");
    }
})