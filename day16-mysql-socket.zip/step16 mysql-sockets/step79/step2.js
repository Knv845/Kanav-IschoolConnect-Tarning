const res = require("express/lib/response");
let mysql = require("mysql");

let connection = mysql.createConnection({
    host : "localhost",
    user : "root",
    password : "",
    port : "3308",
    database : "ischooldb"
})

connection.connect(function(error){
    if(error){
        console.log("error",error)
    }else{
        //console.log("Mysql connected to onlinedb")
// let sql =  "CREATE TABLE powers (id INT AUTO_INCREMENT PRIMARY KEY, power VARCHAR(225))"

    //    connection.query(sql,function(error,result){
    //        if(error){
    //            console.log("error from query")
    //        }else{
    //            console.log("result",result)
    //        }
    //    })

       //let sql = "INSERT INTO participants (name,email) VALUES ('ironman', 'ironman@gmail.com')";

        //  connection.query(sql, function(error,result){
        //      if(error){
        //          console.log(error)
        //      }else{
        //          console.log(result)
        //      }
        //  })

        // let heros = [
        //     ["Superman"],
        //     ["Batman"],
        //     ["Spiderman"],
        //     ["ironman"],
        //     ["black panther"]
        // ];
        //  let sql = "INSERT INTO participants (name) VALUES ?";
        // // connection.query(sql,[heros],function(error,result){
        //     let power = [
        //             ["Strong"],
        //             ["Rich"],
        //             ["Web"],
        //             ["armor"],
        //             ["King"]
        //         ];
        //          let sql = "INSERT INTO powers  (power) VALUES ?";

// assingment 

      // let sql = "SELECT * FROM participants WHERE id < 5";
      //let sql = "SELECT * FROM participants WHERE id > 5";
     // let sql = "SELECT * FROM participants GROUP BY id having mod(id,2)=1;";

    // let sql = `SELECT participants.name, powers.power FROM participants INNER JOIN powers ON participants.id = powers.id`;
   // let sql = `SELECT participants.name, powers.power FROM participants LEFT JOIN powers ON participants.id = powers.id` 
   //let sql = `SELECT participants.name, powers.power FROM participants RIGHT JOIN powers ON participants.id = powers.id`
     connection.query(sql,function(error,result){
                 if(error){
                     console.log(error)
                 }else{
                     console.log(result)
                    //  result.forEach(element => {
                    //      console.log(element.name)
                    //  });
                 }
             })

       // let sql =  "CREATE TABLE awars (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(225),email VARCHAR(300))"



    }
})
    
