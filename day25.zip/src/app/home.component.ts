import { Component } from "@angular/core";
import { User } from "./user.model";
import { IschoolUserService } from "./user.service";


@Component({
    selector:'app-home',
    template:`
       <div class="container">
       <div> 
        <h2>Users List</h2>
        <table class="table table-striped table-bordered table-responsive">
        <thead>
          <tr>
              <th> Sl # </th>
              <th> User Name </th>
              <th> User Mail </th>
              <th> User City </th>
              <th> Edit User Info </th>
              <th> Delete User </th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let user of userdata; index as idx;">
            <td>{{ idx + 1 }}</td>
            <td>{{ user.username }} 
            <td>{{ user.usermail }}</td>
            <td>{{ user.usercity }}</td>
            <td>
              <button (click)="editUser(user)" class="btn btn-warning">Edit</button>
            </td>
            <td>
              <button (click)="deleteUser(user)" class="btn btn-danger">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
      </div>
       </div>
    `
})

export class HomeComponent {
  showEditBox = false;
  userdata:Array<User> = [
    { 
      username : 'Batman',
      usermail : 'bruce@wayne.com',
      usercity : 'Gotham' 
    }
  ];
  newuserdata:User = { 
    username : '',
    usermail : '',
    usercity : '' 
  };
  userToUpdate = { 
    username : '',
    usermail : '',
    usercity : '',
    _id : '',
  };
  constructor( private us:IschoolUserService ){}
  reload(){
    this.us.getUsers().subscribe((res:any) => this.userdata = res);
  }
  ngOnInit(){
    this.reload();
  }
  addNewUser(){
    this.us.postUsers(this.newuserdata).subscribe(res => {
      this.reload();
      console.log(res);
      this.newuserdata = { 
        username : '',
        usermail : '',
        usercity : '' 
      };
    })
  }
  editUser(user:any){
    this.us.getUserToEdit(user._id).subscribe((res:any) => {
        this.userToUpdate = res;
        this.showEditBox = true;
    })
  }
  updateUserInfo(userid:any){
    this.us.postUserToEdit(userid,this.userToUpdate).subscribe(res=>{
      console.log(res);
      this.reload();
      this.userToUpdate = { 
        username : '',
        usermail : '',
        usercity : '',
        _id : '',
      };
      this.showEditBox = false;
    })
  }
  deleteUser(user:any){
    this.us.deleteUser(user._id).subscribe((res) => {
      console.log(res);
      this.reload();
    })
  }

}