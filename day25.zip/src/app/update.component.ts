import { Component } from "@angular/core";
import { IschoolUserService } from "./user.service";


@Component({
    selector:'app-update',
    template:`
        <div class="container">
        <div *ngIf="showEditBox">
        <h2>Update User</h2>
        <form name="updateUserForm" #updateUserForm="ngForm">
        <div class="mb-3">
          <label for="edit_username" class="form-label">Update User Name</label>
          <input name="uname" #edit_uname="ngModel" [(ngModel)]="userToUpdate.username" class="form-control" id="edit_username">
        </div>
        <div class="mb-3">
          <label for="edit_usermail" class="form-label">Update User Mail</label>
          <input name="umail" #edit_umail="ngModel" [(ngModel)]="userToUpdate.usermail" class="form-control" id="edit_usermail">
        </div>
        <div class="mb-3">
          <label for="edit_usercity" class="form-label">Update User City</label>
          <input name="ucity" #edit_ucity="ngModel" [(ngModel)]="userToUpdate.usercity" class="form-control" id="edit_usercity">
        </div>
        <button (click)="updateUserInfo(userToUpdate._id)" type="submit" class="btn btn-primary">Update User</button>
      </form>
      </div>
        </div>
    `
})

export class UpdateComponent{
    showEditBox = false;
    userToUpdate = { 
        username : '',
        usermail : '',
        usercity : '',
        _id : '',
      };
      constructor( private us:IschoolUserService ){}
     editUser(user:any){
        this.us.getUserToEdit(user._id).subscribe((res:any) => {
            this.userToUpdate = res;
            this.showEditBox = true;
        })
      }
      updateUserInfo(userid:any){
        this.us.postUserToEdit(userid,this.userToUpdate).subscribe(res=>{
          console.log(res);
          this.userToUpdate = { 
            username : '',
            usermail : '',
            usercity : '',
            _id : '',
          };
          this.showEditBox = false;
        })
      }
}