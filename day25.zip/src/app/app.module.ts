import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { IschoolUserService } from './user.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HomeComponent } from './home.component';
import { DefaultComponent } from './default.componet';
import { AddComponent } from './add.component';
import { UpdateComponent } from './update.component';

@NgModule({
  declarations: [
    AppComponent,DefaultComponent,HomeComponent,AddComponent,UpdateComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,RouterModule.forRoot([
      {path:"",component:DefaultComponent},
      {path:"list",component:HomeComponent},
      {path:"add",component:AddComponent},
      {path:"update/:userid",component:UpdateComponent},
      {path:"delete",component:DefaultComponent}
    ])
  ],
  providers: [IschoolUserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
