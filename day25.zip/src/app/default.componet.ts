import { Component } from "@angular/core";

@Component({
    selector:'app-default',
    template:`
    Welcome to The Crud application
    `
})

export class DefaultComponent{

}