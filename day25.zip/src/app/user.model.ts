export class User{
    constructor(public username:string ,public usermail:string,public usercity:string){}
}