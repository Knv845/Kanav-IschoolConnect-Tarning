import { Component, Input } from "@angular/core";
import { HerodataServices } from "./hero.services";

@Component({
    selector:'app-grid',
    template:`
    <h2>App version: {{compversion}}</h2>
        <table class="table table-striped table-bordered">
    <thead>
      <tr> 
          <th>Sl #</th> 
          <th>Title</th> 
          <th>Full Name</th> 
          <th>Poster</th> 
          <th>City</th> 
          <th>Ticket Price</th> 
          <th>Release Date</th> 
          <th>Movies List</th> 
      </tr>
    </thead>
    <tbody>
      <tr *ngFor="let hero of compdata"> 
        <td>{{ hero.sl }}</td> 
        <td>{{ hero.title | uppercase }}</td> 
        <td>{{ hero.firstname+" "+hero.lastname | gen : hero.gender}}</td> 
        <td>
          <img class="img-thumbnail" [src]="hero.poster" [alt]="hero.title" width="50">
        </td> 
        <td>{{ hero.city }}</td> 
        <td>{{ hero.ticketprice | currency : 'INR' : 'symbol' : '3.2-4' }}</td> 
        <td>{{ hero.releasedate | date : 'dd / MMMM / yyyy' }}</td> 
        <td>
          <div *ngIf="hero.movieslist.length > 0" class="card">
            <ul class="list-group list-group-flush">
              <li *ngFor="let movie of hero.movieslist" class="list-group-item">
              <img [src]="movie.poster" width="30"/> 
              {{ movie.title }}
              </li>
            </ul>
          </div>
        </td> 
      </tr>
    </tbody>
  </table>
    `

})

export class GridComponent{
//    @Input() compdata:any
   compdata:any;
   compversion:any;

   constructor(private  hds:HerodataServices){
      //  this.compdata = this.hds.getHerodata();
      this.hds.getHerodata().subscribe((res)=>{
        this.compdata=res;
      })
       this.compversion = this.hds.getappversion();
   }
}