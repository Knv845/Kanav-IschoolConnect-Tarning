import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import{ HttpClientModule } from '@angular/common/http'

import { AppComponent } from './app.component';
import { GridComponent } from './grid.component';
import { HeaderComponent } from './header.component';
import { HerodataServices } from './hero.services';
import { GenPipe } from './gen.pipe';
import { IschoolDirective } from './ischool.directive';

@NgModule({
  declarations: [
    AppComponent,HeaderComponent,GridComponent,GenPipe,IschoolDirective
  ],
  imports: [
    BrowserModule,HttpClientModule
  ],
  providers: [HerodataServices],
  bootstrap: [AppComponent]
})
export class AppModule { }
