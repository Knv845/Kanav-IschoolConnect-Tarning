import { Directive , OnInit, ElementRef} from "@angular/core";

@Directive({
    // selector:'.ischool'
    // selector:'ischool'
    selector:'[ischool]'
})

export class IschoolDirective implements OnInit {
    constructor(private elm:ElementRef){}
    ngOnInit() {
        this.elm.nativeElement.innerHTML = "<p>Hello from Ischool India</p>"
        this.elm.nativeElement.style.color="red"
    }
}