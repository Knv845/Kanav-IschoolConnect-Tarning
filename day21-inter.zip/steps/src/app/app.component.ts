import { Component } from '@angular/core';
 
@Component({
  selector: 'app-root',
  template : `
  <div class="container">
  <h1>Angular Data Handling</h1>
  <hr>
  <app-header></app-header>
  <hr>
  <app-grid></app-grid>
 <!-- <ischool> <p>Some Text</p></ischool>     // tremplate selctor--> 
  <!-- <p class="ischool">Some Text</p>    // class sector -->
  <p ischool>Some Text</p>
  </div>
  `
})
export class AppComponent {
  title = 'steps';
  appdata:any;
  
  
}