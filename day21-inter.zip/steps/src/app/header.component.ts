import { Component, Input } from "@angular/core";
import { HerodataServices } from "./hero.services";

@Component({
    selector:'app-header',
    template:`
        <ul class="nav justify-content-center">
    <li class="nav-item" *ngFor="let hero of compdata">
      <a class="nav-link">{{hero.title}}</a>
    </li>
  </ul>
  <h2>App version: {{compversion}}</h2>
    `
})

export class HeaderComponent{
    // @Input() compdata:any;
    compdata:any;
    compversion:any;
    constructor( private hds:HerodataServices){
        // this.compdata = this.hds.getHerodata();
        this.hds.getHerodata().subscribe((res)=>{
          this.compdata=res;
        })
        this.compversion = this.hds.getappversion();
    }
} 