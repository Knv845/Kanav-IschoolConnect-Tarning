const express = require('express');
const app = express();
const fs = require('fs')


app.get("/",(req,res)=>{
    res.sendFile(__dirname+'/public/index.html')
})





app.listen(4000,function(error){
    if(error){
        console.log('error from listen')
    }else
        console.log('server is running at 4000')
})