const express = require('express');
const app = express();
const fs = require('fs');
const mongoose = require('mongoose');
const { userInfo } = require('os');


// middleware
app.use(express.static(__dirname+"/public"))
app.use(express.json());

//config for mongoose
const url = "mongodb+srv://admin:password$123@MyCluster.yu9yw.mongodb.net/onlinedb?retryWrites=true&w=majority";
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let Categories = mongoose.model('Categories',new Schema({
    id : ObjectId,
    category : String

}));
let Answers = mongoose.model('Answers',new Schema({
    id : ObjectId,
    answer : String

}));
let QuestionAnswers = mongoose.model('QuestionAnswers',new Schema({
    id : ObjectId,
    domain : String,
    question : String,
    answer : String,
    answernew : String    
}));





// mongoose Connect
mongoose.connect(url)
.then(()=>{console.log('database Connected')})
.catch((error)=>{console.log('Error occur in  Connecting DB')})



//routes
// display a html file
app.get("/",(req,res)=>{
    res.sendFile(__dirname+'/public/index.html')
})

// recieving data for category
app.post("/category",(req,res)=>{
    //console.log('recieved data',req.body)
    let categorynew = new Categories(req.body)
    categorynew.save()
    .then(function(dbres){
        console.log(' Category data pushed to db')
    })
    .catch(function(error){
        console.log('error form posted data')
    })

})

// recieving data for answer
app.post("/answer",(req,res)=>{
    //console.log('data recieved form answer post',req.body)
    let answernew = new Answers(req.body)
    answernew.save()
    .then(function (dbres) {
        console.log("Answer data pushed to  db")
      })
    .catch(function(error){
        console.log('error in push answer to db')
    })
})

// recievng data from question answers and all
app.post("/questionanswers",(req,res)=>{
    //console.log('data recieved form answer post',req.body)
    let quesnew = new QuestionAnswers(req.body)
    quesnew.save()
    .then(function (dbres) {
        console.log("all data pushed to  db");
         })
    .catch(function(error){
        console.log(error)
    })
})




// port
app.listen(4000,function(error){
    if(error){
        console.log('error from listen')
    }else
        console.log('server is running at 4000')
})