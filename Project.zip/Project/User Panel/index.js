const express = require('express');
const app =  express();
const fs = require('fs')
const mongoose = require('mongoose')

app.use(express.static(__dirname+"/public"))
app.use(express.json());

//config for mongoose
const url = "mongodb+srv://admin:password$123@MyCluster.yu9yw.mongodb.net/onlinedb?retryWrites=true&w=majority";
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let questionanswers = mongoose.model('questionanswers',new Schema({
    id : ObjectId,
    question : String
}))


//connection of db
mongoose.connect(url)
.then(()=>{console.log('database Connected')})
.catch((error)=>{console.log('Error occur in  Connecting DB')})





//routes
app.get("/data",(req,res)=>{
    questionanswers.find(function(error, questionanswers){
        if(error){
            console.log("error in get")
        }else{
            {res.json(questionanswers)}
        }
    })
})





app.listen(3000,'localhost',function(error){
    if(error){
        console.log("error form port");
    }else{
        console.log("server is running fine at 3000");
    }
})






