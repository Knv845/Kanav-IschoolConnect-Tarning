import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MasterComponent } from './master.component';
import { DetailComponent } from './detail.component';
import { RouterModule } from '@angular/router';
import { HeroesService } from '../../../step3-query-optional-parameters/src/app/heroes.service';
import { HeroEditComponent } from './hero-edit.component';
import { FormsModule } from '@angular/forms';
import { HeroComponent } from './hero/hero.component';

@NgModule({
  declarations: [
    AppComponent,
    MasterComponent,
    DetailComponent,
    HeroEditComponent,
    HeroComponent
  ],
  imports: [
    BrowserModule,FormsModule,RouterModule.forRoot([
      {path:"",component: MasterComponent},
      {path:"hero/:selectedId",component: DetailComponent}
    ])
  ],
  providers: [HeroesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
