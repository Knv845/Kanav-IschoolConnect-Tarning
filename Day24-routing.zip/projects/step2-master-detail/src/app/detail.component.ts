import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HeroesService } from '../../../step3-query-optional-parameters/src/app/heroes.service';

@Component({
  selector: 'app-detail',
  template: `
    <h2>{{selectedHero.name}}</h2>
    <br>
    <img [src]="'assets/'+selectedHero.image.url">

    <p>{{selectedHero | json}}}</p>

    <a [routerLink] = "['edit',selectedHero.powerstasts.power,selectedHero,name]">Edit {{selectedHero.name}}</a>
    <br>
    <input min="0" max="100" type="range" [(ngModel)]="selectedHero.name">

  `,
  styles: [
  ]
})
export class DetailComponent implements OnInit {
   selectedHero:any;
  constructor(private ar:ActivatedRoute, private hs:HeroesService) { }

  ngOnInit(): void {
    this.selectedHero = this.hs.getSelectedHeroes(this.ar.snapshot.params['selectedId'])
  }

}
