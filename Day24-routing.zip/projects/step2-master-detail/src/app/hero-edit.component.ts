import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-hero-edit',
  template: `
    <h2>Hero to update: {{herotoedit}}</h2>
    <h2>update new power {{heronewpower}</h2>
  `,
  styles: [
  ]
})
export class HeroEditComponent implements OnInit {
  herotoedit:any;
  heronewpower:any;
  constructor(private ar:ActivatedRoute) { }

  ngOnInit(): void {
    this.herotoedit = this.ar.snapshot.params['hname'];
    this.ar.params.subscribe(rparams=>{
      this.heronewpower = rparams['power']
    })
  }

}
