import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HeroesService } from './heroes.service';

@Component({
  selector: 'app-master',
  template: `
    <input [(ngModel)]="filterby" type="search">
  <table>
    <thead>
      <tr>
          <th>s1</th>
          <th>Title</th>
          <th>Full Name</th>
          <th>More Details</th>
      </tr>
    </thead>
    <tbody>
      <tr *ngFor="let hero of herolist | herofilter:filterby">
         <td>{{hero.id}}</td>
         <td>{{hero.name}}</td>
         <td>{{hero.biography['full name']}}</td>
         <td>
            <a [routerLink]="['hero']" [queryParams]="{hid : hero.id, filteron : filterby}">Click For details</a>
         </td>
      </tr>
    </tbody>
  </table>
  `,
  styles: [
  ]
})
export class MasterComponent implements OnInit {
   herolist:any;
   filterby:any;
  constructor(private hs:HeroesService, private ar:ActivatedRoute) { }

  ngOnInit(): void {
    this.herolist = this.hs.getHeroes();
    this.filterby = this.ar.snapshot.queryParams['filteron']
  }

}
