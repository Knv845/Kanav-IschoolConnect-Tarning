import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HeroesService } from './heroes.service';

@Component({
  selector: 'app-detail',
  template: `
    <a [routerLink]="['']" queryParamsHandling="preserve">Back to master page </a>
    <h2>{{selectedHero.name}} : power {{selectedHero.powerstats.power}}</h2>
    <br>
    <img [src]="'assets/'+selectedHero.image.url">

    <p>{{selectedHero | json}}}</p>

    <a [routerLink] = "['edit',selectedHero.powerstats.power,selectedHero.name]">Edit:{{ selectedHero.name }}</a>
    <br>
    <input min="0" max="100" type="range" [(ngModel)]="selectedHero.powerstats.power">
    <a [routerLink] = "['edit',selectedHero.powerstats.power.selectedHero.name]">Set Power Of {{selectedHero.name}}</a>

  `,
  styles: [
  ]
})
export class DetailComponent implements OnInit {
   selectedHero:any;
   masterfilteron:any;
  constructor(private ar:ActivatedRoute, private hs:HeroesService) { }

  ngOnInit(): void {
    this.selectedHero = this.hs.getSelectedHeroes(this.ar.snapshot.queryParams['hid'])
    this.masterfilteron = this.hs.getSelectedHeroes(this.ar.snapshot.queryParams['filteron'])
  }

}
