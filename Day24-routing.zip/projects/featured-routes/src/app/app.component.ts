import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <ul class="nav  nav-pills nav-justified p-5">
  <li class="nav-item">
    <a [routerLink]="['']">Home</a>
  </li>
  <li class="nav-item">
    <a  [routerLink]="['hero']">Hero</a>
  </li>
  <li class="nav-item">
    <a  [routerLink]="['movie']">Movie</a>
</li>
<li class="nav-item">
    <a  [routerLink]="['heroadd']">Movie</a>
</li>

</ul>
  <router-outlet></router-outlet>
    
  `,
  styles: []
})
export class AppComponent {
  title = 'featured-routes';
}
