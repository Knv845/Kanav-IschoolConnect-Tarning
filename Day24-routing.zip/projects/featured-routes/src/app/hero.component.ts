import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hero',
  template: `
    <div class="container"> <h1>Welcome To Hero</h1></div>
    <ul class="nav  nav-pills nav-justified p-2">
  <li class="nav-item">
    <a [routerLink]="['heroes']">Heros</a>
  </li>
  <li class="nav-item">
    <a  [routerLink]="['heroedit']">Hero</a>
  </li>
  <li class="nav-item">
    <a  [routerLink]="['heroadd']">Movie</a>
</li>

  `,
  styles: [
  ]
})
export class HeroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
