import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movie',
  template: `
    <p>
      movie works!
    </p>
  `,
  styles: [
  ]
})
export class MovieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
