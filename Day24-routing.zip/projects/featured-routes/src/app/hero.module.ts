import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HerolistComponent } from './herolist.component';
import { HeroaddComponent } from './heroadd.component';
import { HeroComponent } from './hero.component';
import { HeroeditComponent } from './heroedit.component';
import { RouterModule } from '@angular/router';
import { MovieComponent } from './movie.component';



@NgModule({
  declarations: [HeroComponent,HerolistComponent,HeroaddComponent,HeroeditComponent],
  imports:[RouterModule.forChild([
    {path:"hero",component:HeroComponent},
    {path:"heroes",component:HerolistComponent},
    {path:"heroadd",component:HeroaddComponent},
    {path:"heroedit",component:HeroeditComponent},
  ])],
  exports:[HeroComponent,HerolistComponent,HeroaddComponent,HeroeditComponent]
})
export class HeroModule { }
