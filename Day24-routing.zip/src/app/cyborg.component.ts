import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cyborg',
  template: `
    <p>
      cyborg works!
    </p>
  `,
  styles: [
  ]
})
export class CyborgComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
