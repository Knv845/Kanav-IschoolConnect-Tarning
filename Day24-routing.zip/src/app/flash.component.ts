import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flash',
  template: `
    <p>
      flash works!
    </p>
  `,
  styles: [
  ]
})
export class FlashComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
