import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h2>Routing 101</h2>
    <hr>
      <!-- <ul>
        <li> <a href="">Home</a></li>
        <li> <a href="batman">Batman</a></li>
        <li> <a href="superman">superman</a></li>
        <li> <a href="aquaman">aquaman</a></li>
        <li> <a href="wonderwomen">wonderwomen</a></li>
        <li> <a href="hulk">hulk</a></li>
        <li> <a href="cyborg">cyborg</a></li>
      </ul> -->
      <input #qty type="range" (input)="setQuantity = qty.value ">
      <br>
      <ul>
        <li> <a [routerLink]="['']">Home</a></li>
        <li> <a [routerLink]="['batman']">Batman</a></li>
        <li> <a [routerLink]="['batman',setQuantity]">Batman</a></li>
        <li> <a [routerLink]="['superman']">superman</a></li>
        <li> <a [routerLink]="['aquaman']">aquaman</a></li>
        <li> <a [routerLink]="['wonderwomen']">wonderwomen</a></li>
        <li> <a [routerLink]="['hulk']">hulk</a></li>
        <li> <a [routerLink]="['cyborg']">cyborg</a></li>
      </ul>
    <hr>
    <router-outlet></router-outlet>    
  `,
  styles: []
})
export class AppComponent {
  title = 'steps';
  setQuantity:any;
  constructor(){

  }
}
