import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aquaman',
  template: `
     <h1>hi from aquaman</h1>
     <p>

       Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero, dolor ipsa nesciunt dignissimos, ad ratione eaque quaerat aperiam labore temporibus possimus asperiores in, consequatur a molestiae quidem sit nobis accusamus?
       Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam ea officia possimus distinctio? Sint illo fuga, sequi culpa, molestiae similique adipisci officia unde tempora veniam rerum laboriosam! Corrupti, magnam nulla.
       Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit fugit unde quos asperiores quaerat fuga repudiandae repellat fugiat eveniet suscipit minima temporibus debitis, iusto rerum ea architecto doloremque quis quae.
     </p>
  `,
  styles: [
  ]
})

export class AquamanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
