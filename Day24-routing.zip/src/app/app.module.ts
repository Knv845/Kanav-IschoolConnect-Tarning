import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { SupermanComponent } from './superman.component';
import { AquamanComponent } from './aquaman.component';
import { FlashComponent } from './flash.component';
import { WonderwomenComponent } from './wonderwomen.component';
import { CyborgComponent } from './cyborg.component';
import { NotfoundComponent } from './notfound.component';
import { RouterModule } from '@angular/router';
import { BatmanComponent } from './batman.component';
import { HomeComponent } from './home.component';

@NgModule({
  declarations: [
    AppComponent,
    SupermanComponent,
    AquamanComponent,
    FlashComponent,
    WonderwomenComponent,
    CyborgComponent,
    NotfoundComponent,
    BatmanComponent,
    HomeComponent,
  ],
  imports: [
    BrowserModule,RouterModule.forRoot([
      {path:"",component: HomeComponent },
      {path:"batman",component: BatmanComponent },
      {path:"batman/:qty",component: BatmanComponent },
      {path:"aquaman",component: AquamanComponent },
      {path:"superman",component: SupermanComponent },
      {path:"flash",component: FlashComponent },
      {path:"wonderwomen",component: HomeComponent },
      {path:"cyborg",component: CyborgComponent },
      {path:"**",component: NotfoundComponent }

    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
