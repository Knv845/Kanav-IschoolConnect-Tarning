import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wonderwomen',
  template: `
    <p>
      wonderwomen works!
    </p>
  `,
  styles: [
  ]
})
export class WonderwomenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
