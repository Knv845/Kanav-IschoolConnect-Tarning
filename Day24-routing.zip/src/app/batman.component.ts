import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-batman',
  template: `
    <p>
      batman works!
    </p>
    <h3>Quantity : {{quantity || "0"}}</h3>
  `,
  styles: [
  ]
})
export class BatmanComponent implements OnInit {
  quantity:any;
  constructor(private ar:ActivatedRoute) { }

  ngOnInit(): void {
    this.quantity = this.ar.snapshot.params['qty']
  }

}
