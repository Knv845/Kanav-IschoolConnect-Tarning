import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-superman',
  template: `
    <p>
      superman works!
    </p>
  `,
  styles: [
  ]
})
export class SupermanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
