import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HeroesService } from './heroes.service';

@Component({
  selector: 'app-heroedit',
  template: `
    <h2>Welcome to Hero Edit</h2>
    <hr>
    <div class="container">
    <h4>Edit : {{selectedhero.name}} </h4>
      <!-- 
       <h6>{{selectedhero | json}}</h6> -->
      <br>
<div class="card mb-3 text-center" style="max-width: 900px;">
  <div class="row g-0">
    <div class="col-md-4">
      <img [src]="'assets/'+selectedhero.image.url" class="img-fluid rounded-start" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h3 class="card-title">{{selectedhero.biography['full-name']}}</h3>
        <ul class="list-group list-group-flush">
    <li class="list-group-item"><h6> Intelligence : {{selectedhero.powerstats['intelligence']}}</h6></li>
    <li class="list-group-item"><h6>Strength : {{selectedhero.powerstats['strength']}}</h6></li>
    <li class="list-group-item"><h6>Speed : {{selectedhero.powerstats['speed']}}</h6></li>
  </ul>
      </div>
    </div>
  </div>
  <br>
  <h4>Now You Can Change The Intelligence : </h4>
  <input #power type="range" min="0" max="100" [(ngModel)] = "selectedhero.powerstats.intelligence">
</div>
    </div>

  `,
  styles: [`
    .card{
      border : none
    }
  `]
})
export class HeroeditComponent implements OnInit {
  selectedhero:any;
  constructor(private hs:HeroesService, private ar:ActivatedRoute) { }

  ngOnInit(): void {
    this.selectedhero = this.hs.getSelectedHeroes(this.ar.snapshot.params['selectedId'])
  }

}
