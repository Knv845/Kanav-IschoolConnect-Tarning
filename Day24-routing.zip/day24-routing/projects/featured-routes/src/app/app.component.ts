import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <ul class="nav  nav-pills nav-justified p-5">
  <li class="nav-item">
    <button class="btn btn-primary"  [routerLink]="['']">Home</button>
  </li>
  <li class="nav-item">
  <button class="btn btn-primary" [routerLink]="['hero']"> Hero/Herolist</button>
  </li>
  <!-- <li class="nav-item">
  <a [routerLink]="['heroes']">Hero List</a>
  </li> -->
  <!-- <li class="nav-item">
  <a [routerLink]="['heroedit']">Edit Hero</a>
  </li> -->
  <li class="nav-item">
  <button class="btn btn-primary" [routerLink]="['heroadd']">Add Hero</button>
  </li>
  <li class="nav-item">
  <button class="btn btn-primary" [routerLink]="['movie']">Movie/Movie List</button> 
  <!-- </li>
  <li class="nav-item">
  <a [routerLink]="['movies']">Movie List</a>
  </li> -->
  <li class="nav-item">
  <button class="btn btn-primary" [routerLink]="['movieadd']">Add Movie</button>
  </li>
  <!-- <li class="nav-item">
  <a [routerLink]="['movieedit']">Edit Movie</a>
  </li> -->
</ul>
  <router-outlet></router-outlet>
    
  `,
  styles: []
})
export class AppComponent {
  title = 'featured-routes';
}
