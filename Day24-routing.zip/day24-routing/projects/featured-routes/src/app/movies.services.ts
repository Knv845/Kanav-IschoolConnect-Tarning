import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root',
})

export class MovieService{
    moviedata = {
        "movies": [
            {
              "id": "1",
              "name": "The Dark Knight",
              "rating": "8.2"
            },
            {
                "id": "2",
                "name": "The Dark Knight Begin",
                "rating": "5.2"
              },
              {
                "id": "3",
                "name": "The Dark Knight Rises",
                "rating": "9.2"
              },
              {
                "id": "4",
                "name": "The Superman",
                "rating": "7.2"
              },
              {
                "id": "5",
                "name": "The Hulk",
                "rating": "8.2"
              },
        ],
    };
    getmovies(){
        return this.moviedata.movies

    }
    getmovieid(movieid:any){
      return this.moviedata.movies[movieid-1]

    }

}