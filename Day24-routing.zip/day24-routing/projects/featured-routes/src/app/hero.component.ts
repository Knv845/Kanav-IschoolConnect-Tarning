import { Component, OnInit } from '@angular/core';
import { HeroesService } from './heroes.service';

@Component({
  selector: 'app-hero',
  template: `
    <div class="container"> 
      <h1>Welcome To Hero</h1>
    <br>
  <table class="table">
  <thead>
    <tr>
      <th scope="col">S no</th>
      <th scope="col">Hero Name</th>
      <th scope="col">Full Name</th>
    </tr>
  </thead>
  <tbody>
    <tr *ngFor="let hero of herolist">
         <td>{{hero.id}}</td>
         <td>{{hero.name}}</td>
         <td>{{hero.biography['full-name']}}</td>
         <td>
           <button class="btn btn-warning" [routerLink]="['/heroedit', hero.id]">Click To Edit</button>
         </td>
    </tr>
  </tbody>
</table>
    </div>
      
    `,
  styles: [
  ]
})
export class Hero1Component implements OnInit {
  herolist:any=" ";
  constructor(private hds:HeroesService) {
    
   }
 ngOnInit(): void {
  this.herolist = this.hds.getHeroes()
 }

}
