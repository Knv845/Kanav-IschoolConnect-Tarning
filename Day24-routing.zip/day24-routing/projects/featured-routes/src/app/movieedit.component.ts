import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MovieService } from './movies.services';

@Component({
  selector: 'app-movieedit',
  template: `
   <h1> Welcome To Movie Edit </h1>
   <hr>
   <!-- <h2>Movie To Edit : {{selectedmovie.name}} </h2> -->
   <br>
   <div class="container">
   <div class="card">
  <div class="card-header">
  <h3>Movie To Edit : {{selectedmovie.name}} </h3>
  </div>
  <div class="card-body">
    <h5 class="card-title">Rating : {{selectedmovie.rating}}</h5>
    <br>
    <input #rating min="0" max="10" step="0.1"  type="range" [(ngModel)]="selectedmovie.rating" >
   
  </div>
</div>
   </div>
  `,
  styles: [
  ]
})
export class MovieeditComponent implements OnInit {
  selectedmovie:any;
  constructor(private ms:MovieService, private ar:ActivatedRoute) { }

  ngOnInit(): void {
    this.selectedmovie = this.ms.getmovieid(this.ar.snapshot.params['selectedId'])
  }

}
