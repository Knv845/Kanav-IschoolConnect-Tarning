import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heroadd',
  template: `
   <h1>Under Construction !!</h1>
  `,
  styles: [
  ]
})
export class HeroaddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
