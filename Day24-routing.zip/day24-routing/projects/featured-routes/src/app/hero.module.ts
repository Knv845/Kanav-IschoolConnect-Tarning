import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HerolistComponent } from './herolist.component';
import { HeroaddComponent } from './heroadd.component';
import { Hero1Component } from './hero.component';
import { HeroeditComponent } from './heroedit.component';
import { RouterModule } from '@angular/router';
import { HeroesService } from './heroes.service';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [Hero1Component,HerolistComponent,HeroaddComponent,HeroeditComponent],
  imports:[CommonModule,FormsModule,RouterModule.forChild([
    {path:"hero",component:Hero1Component},
    {path:"heroes",component:HerolistComponent},
    {path:"heroadd",component:HeroaddComponent},
    {path:"heroedit/:selectedId",component:HeroeditComponent},
  ])],
  providers:[HeroesService],
  exports:[Hero1Component,HerolistComponent,HeroaddComponent,HeroeditComponent]
})
export class HeroModule { }
