import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MasterComponent } from './master.component';
import { DetailComponent } from './detail.component';
import { RouterModule } from '@angular/router';
import { HeroesService } from './heroes.service';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from './home.component';
import { HeroResolverService } from './hero.resolver.service';

@NgModule({
  declarations: [
    AppComponent,
    MasterComponent,
    DetailComponent,
    HomeComponent

  ],
  imports: [
    BrowserModule,FormsModule,RouterModule.forRoot([
      {path:"",component:HomeComponent},
      {path:"list",component: MasterComponent,data:{applist:'ischol connect'},resolve:{herodata:HeroesService}},
      {path:"hero/:selectedId",component: DetailComponent,{singleherodata:HeroResolverService}}
    ])
  ],
  providers: [HeroesService,HeroResolverService,SingleHeroDataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
