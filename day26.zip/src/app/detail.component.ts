import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HeroesService } from './heroes.service';

@Component({
  selector: 'app-detail',
  template: `
    <h2>{{selectedHero.name}}</h2>
    <br>
    <img [src]="'assets/'+selectedHero.image.url">

    <p>{{selectedHero | json}}}</p>
  `,
  styles: [
  ]
})
export class DetailComponent implements OnInit {
   selectedHero:any;
  constructor(private ar:ActivatedRoute, private hs:HeroesService) { }

  ngOnInit(): void {
    // this.selectedHero = this.hs.getSelectedHeroes(this.ar.snapshot.params['selectedId'])
    this.ar.data.subscribe(res => this.selectedHero = res['singleherodata'])
  }

}
