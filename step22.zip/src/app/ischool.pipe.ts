import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name:"ischool"
})

export class IschoolPipe implements PipeTransform{
    transform(...arg:any) {
        if(arg[1] ==  "central"){
            return arg[0]+" is from "+arg[1]+" part of India"
        }else{
            return arg[0]+" is from "+arg[1]+"ern part of India"
        }
        // if(arg2 == "north"){
        //     return arg1+" "+"is from Northern India"
        // }else if(arg2 == "central"){
        //     return arg1+" "+"is from Central India"
        // }else if(arg2 == "south"){
        //     return arg1+" "+"is from South India"
        // }else if(arg2 == "east"){
        //     return arg1+" "+"is from East India"
        // }
        // else{
        //     return arg1
        // }
    }
}