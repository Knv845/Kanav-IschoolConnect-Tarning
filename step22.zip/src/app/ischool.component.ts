import { Component, Input } from "@angular/core";

@Component({
    selector: 'app-ischool',
    template: `<h2 [ischool]="participant.favCol">{{participant.title | ischool : participant.region}}</h2>`,
})

export class IschoolComp{
    @Input() participant = {
        title: '',
        region : '',
        favCol : ''
    }
}