import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Welcome to Day22</h1>
    <div *ngFor="let participant of participants">
      <!-- <h2 [ischool]="participant.favCol">{{participant.title | ischool : participant.region | uppercase}}</h2> -->
        <app-ischool [participant]="participant"></app-ischool>
    </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'steps';
  participants =
  [ 
    {"title":"Kanav Khera","region":"north","favCol":"#11D940"},
    {"title":"Rajesh kumar","region":"north","favCol":"#07DAF0"},
    {"title":"Mani Varshney","region":"east","favCol":"#11D940"},
    {"title":"Renu Verma","region":"central","favCol":"#BDF007"},
    {"title":"Sainath Arjun","region":"south","favCol":"#E6AF07"},  

  ]
}
