import { NgModule } from "@angular/core";
import { IschoolComp } from "./ischool.component";
import { IschoolDirective } from "./ischool.directive";
import { IschoolPipe } from "./ischool.pipe";

@NgModule({
    declarations:[IschoolComp,IschoolDirective,IschoolPipe],
    exports:[IschoolComp,IschoolDirective,IschoolPipe]
})

export class IschoolModule{

}