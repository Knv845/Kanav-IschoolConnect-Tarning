import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { IschoolComp } from './ischool.component';
import { IschoolDirective } from './ischool.directive';
import { IschoolModule } from './ischool.module';
import { IschoolPipe } from './ischool.pipe';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,IschoolModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
