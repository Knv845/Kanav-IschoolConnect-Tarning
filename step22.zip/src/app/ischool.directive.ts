import { Directive, ElementRef, Input, OnInit } from "@angular/core";

@Directive({
    selector: '[ischool]'
})

export class IschoolDirective{
    @Input() ischool:any;

    constructor(private elm:ElementRef){}

    ngOnInit(){
        console.log(this.ischool)
        this.elm.nativeElement.style.backgroundColor = this.ischool;
    }
}