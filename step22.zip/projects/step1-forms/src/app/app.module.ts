import { Template } from '@angular/compiler/src/render3/r3_ast';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ReactiveFormBuilder } from './reactive-form-builder.component';
import { ReactiveFormGroup } from './reactive-group.component';
import {TemplateForm } from './template.component';

@NgModule({
  declarations: [
    AppComponent,TemplateForm,ReactiveFormGroup,ReactiveFormBuilder
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
