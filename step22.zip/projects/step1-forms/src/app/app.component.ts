import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
   <div class="container">
   <h2>Forms in Angular</h2>
   <hr>
   <app-template></app-template>
   <hr>
   <app-reactive-form></app-reactive-form>
   <hr>
   <app-reactive-form-builder></app-reactive-form-builder>
   </div>
    
  `,
  styles: []
})
export class AppComponent {
  title = 'step1-forms';
}
