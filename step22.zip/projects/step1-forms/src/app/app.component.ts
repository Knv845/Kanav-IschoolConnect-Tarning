import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
   <div class="container">
   <h2>Forms in Angular</h2>
   <hr>
   <app-template></app-template>
   </div>
    
  `,
  styles: []
})
export class AppComponent {
  title = 'step1-forms';
}
